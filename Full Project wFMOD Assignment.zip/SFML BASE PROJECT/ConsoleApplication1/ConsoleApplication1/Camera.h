#pragma once
class Camera
{
public:
	Camera();
	~Camera();
};

